﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [phone] NCHAR(10) NULL, 
    [address] NCHAR(10) NULL
)
