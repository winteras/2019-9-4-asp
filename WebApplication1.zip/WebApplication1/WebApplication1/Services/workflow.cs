﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml;

namespace WebApplication1.Services
{
    public class workflow
    {
        public string test()
        {
            WebReference.WorkflowServiceService ws = new WebReference.WorkflowServiceService();
            Dictionary<string, string> dic = new Dictionary<string, string>();
            dic.Add("Textbox2","2");
            dic.Add("Textbox3","3");
            dic.Add("Textbox4","4");

            string FormId = ws.findFormOIDsOfProcess("AAA");
            string FormTemplate = ws.getFormFieldTemplate(FormId);

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(XmlReader.Create(new StringReader(FormTemplate)));
            XmlNodeList nodeList = xmlDoc.SelectSingleNode("Assistant").ChildNodes;

            foreach (XmlNode xn in nodeList)
            {
                XmlElement xe = (XmlElement)xn;
                if (dic.ContainsKey(xe.GetAttribute("id")))
                {
                    xe.InnerText = dic[xe.GetAttribute("id")];
                }

            }
            MemoryStream memstream = new MemoryStream(500);
            xmlDoc.Save(memstream);
            //存檔為stream
            string result = Encoding.UTF8.GetString(memstream.ToArray());
            //轉換為string
            string pid = "";

            //啟動流程，回傳 process ID
            pid = ws.invokeProcess("AAA", "42147", "IC02", FormId, result, "");
            //42147 員工 IC02 單位 
            return pid;

        }
    }
}