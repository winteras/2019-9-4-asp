﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ModelTestController : Controller
    {
        // GET: ModelTest
        public ActionResult Index()
        {
            var db = new Database1Entities();
            var data = db.Person.ToList();
            return View(data);
        }

        // GET: ModelTest/Details/5
        public ActionResult Details(int id)
        {
            var db = new Database1Entities();
            var model = db.Person.Where(m => m.Id == id).First();
            return View(model);
        }

        // GET: ModelTest/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ModelTest/Create
        [HttpPost]
        public ActionResult Create(Person model)
        {
            try
            {
                // TODO: Add insert logic here
               var db = new Database1Entities();
                db.Person.Add(model);
                db.SaveChanges();
               return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: ModelTest/Edit/5
        public ActionResult Edit(int id)
        {
            var db = new Database1Entities();
            var model = db.Person.Where(m => m.Id == id).First();
            return View(model);
        }

        // POST: ModelTest/Edit/5
        [HttpPost]
        public ActionResult Edit(Person updateModel)
        {
            try
            {
                // TODO: Add update logic here
                var db = new Database1Entities();
                var model = db.Person.Where(m => m.Id == updateModel.Id).First();
                model.phone = updateModel.phone;
                model.address = updateModel.address;
                db.SaveChanges();
                return RedirectToAction("Index");
                
            }
            catch
            {
                return View();
            }
        }

        // GET: ModelTest/Delete/5
        public ActionResult Delete(int id)
        {
            var db = new Database1Entities();
            var model = db.Person.Where(m => m.Id == id).First();
            return View(model);
        }

        // POST: ModelTest/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                var db = new Database1Entities();
                var model = db.Person.Where(m => m.Id == id).First();
                db.Person.Remove(model);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
